﻿using Microsoft.AspNetCore.Mvc;
using SupportBilling.APPLICATION.Contract;
using SupportBilling.DOMAIN.Entities;

namespace SupportBilling.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InvoicesController : ControllerBase
    {
        private readonly IInvoiceService _invoiceService;

        public InvoicesController(IInvoiceService invoiceService)
        {
            _invoiceService = invoiceService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var invoices = await _invoiceService.GetAllInvoicesAsync();
            if (invoices == null || !invoices.Any())
                return NotFound("No invoices found.");
            return Ok(invoices);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetInvoiceById(int id)
        {
            var invoice = await _invoiceService.GetInvoiceByIdAsync(id);
            if (invoice == null)
                return NotFound($"Invoice with ID {id} not found.");
            return Ok(invoice);
        }

        [HttpPost]
        public async Task<IActionResult> Add(Invoice invoice)
        {
            if (invoice == null)
                return BadRequest("Invoice data cannot be null.");

            // Validaciones adicionales si es necesario
            if (invoice.Subtotal <= 0)
                return BadRequest("Subtotal must be greater than 0.");
            if (invoice.Tax < 0 || invoice.Tax > 100)
                return BadRequest("Tax should be between 0 and 100.");

            try
            {
                await _invoiceService.AddInvoiceAsync(invoice);
                return CreatedAtAction(nameof(GetInvoiceById), new { id = invoice.Id }, invoice);
            }
            catch (Exception ex)
            {
                return BadRequest($"Error while creating the invoice: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, Invoice invoice)
        {
            if (id != invoice.Id)
                return BadRequest("Invoice ID mismatch.");
            if (invoice == null)
                return BadRequest("Invoice data cannot be null.");

            try
            {
                if (invoice.Subtotal <= 0 || invoice.Tax < 0 || invoice.Tax > 100)
                    return BadRequest("Invalid data: subtotal or tax is invalid.");

                await _invoiceService.UpdateInvoiceAsync(invoice);
                return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest($"Error while updating the invoice: {ex.Message}");
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var invoice = await _invoiceService.GetInvoiceByIdAsync(id);
            if (invoice == null)
            {
                return NotFound($"Invoice with ID {id} not found.");
            }

            try
            {
                await _invoiceService.DeleteInvoiceAsync(id);
                return NoContent();
            }
            catch (Exception ex)
            {
                return BadRequest($"Error while deleting the invoice: {ex.Message}");
            }
        }
    }
}
