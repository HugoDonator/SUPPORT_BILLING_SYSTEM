﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace SupportBilling.DOMAIN.Entities
{
    public class Invoice
    {
        public int Id { get; set; }

        [Required]
        public int ClientId { get; set; }
        public virtual Client Client { get; set; } = null!;

        [Required]
        public DateTime InvoiceDate { get; set; }

        [Required]
        public decimal Tax { get; set; } = 18; // El ITBIS (18%) por defecto

        [Required]
        public decimal Subtotal { get; set; }

        public decimal TotalAmount { get; set; }

        [Required]
        public int StatusId { get; set; } // Relacionado con la tabla Status
        public virtual InvoiceStatus Status { get; set; } = null!; // Relación con la tabla InvoiceStatus

        [JsonIgnore] // Evita ciclos al serializar
        public virtual ICollection<InvoiceDetail> InvoiceDetails { get; set; } = new List<InvoiceDetail>();
    }
}
