﻿using Microsoft.EntityFrameworkCore;
using SupportBilling.APPLICATION.Contract;
using SupportBilling.DOMAIN.Entities;
using SupportBilling.INFRASTRUCTURE.Repositories;

namespace SupportBilling.APPLICATION.Service
{
    public class InvoiceService : IInvoiceService
    {
        private readonly BaseRepository<Invoice> _repository;
        private readonly BaseRepository<InvoiceStatus> _statusRepository;

        public InvoiceService(BaseRepository<Invoice> repository, BaseRepository<InvoiceStatus> statusRepository)
        {
            _repository = repository;
            _statusRepository = statusRepository;
        }

        // Obtener todas las facturas
        public async Task<IEnumerable<Invoice>> GetAllInvoicesAsync()
        {
            return await _repository.Query()
                .Include(i => i.Client) // Incluye el cliente relacionado
                .Include(i => i.InvoiceDetails) // Incluye los detalles de la factura
                .ThenInclude(d => d.Service) // Incluye los servicios de cada detalle
                .Include(i => i.Status) // Incluye el estado de la factura
                .ToListAsync();
        }

        // Obtener una factura por ID
        public async Task<Invoice?> GetInvoiceByIdAsync(int id)
        {
            return await _repository.Query()
                .Include(i => i.Client)
                .Include(i => i.InvoiceDetails)
                .ThenInclude(d => d.Service)
                .Include(i => i.Status)
                .FirstOrDefaultAsync(i => i.Id == id);
        }

        // Crear una nueva factura
        public async Task AddInvoiceAsync(Invoice invoice)
        {
            if (invoice == null)
                throw new ArgumentNullException(nameof(invoice));

            if (invoice.InvoiceDetails == null || !invoice.InvoiceDetails.Any())
                throw new InvalidOperationException("La factura debe incluir al menos un detalle.");

            // Validación adicional de los detalles de la factura
            foreach (var detail in invoice.InvoiceDetails)
            {
                if (detail.Quantity <= 0)
                    throw new InvalidOperationException("La cantidad del detalle de la factura debe ser mayor que cero.");
                if (detail.Price <= 0)
                    throw new InvalidOperationException("El precio del detalle de la factura debe ser mayor que cero.");
            }

            // Calcular subtotal y total
            invoice.Subtotal = invoice.InvoiceDetails.Sum(d => d.Quantity * d.Price);
            invoice.Tax = 18;  // ITBIS (impuesto) del 18% por defecto
            invoice.TotalAmount = invoice.Subtotal + (invoice.Subtotal * invoice.Tax / 100);

            // Establecer el estado de la factura como pendiente por defecto
            var status = await _statusRepository.Query().FirstOrDefaultAsync(s => s.Name == "Pending");
            if (status == null)
                throw new InvalidOperationException("El estado 'Pending' no se encuentra en la base de datos.");
            invoice.Status = status;

            await _repository.AddAsync(invoice);
        }

        // Actualizar una factura existente
        public async Task UpdateInvoiceAsync(Invoice invoice)
        {
            if (invoice == null)
                throw new ArgumentNullException(nameof(invoice));

            if (invoice.InvoiceDetails == null || !invoice.InvoiceDetails.Any())
                throw new InvalidOperationException("La factura debe incluir al menos un detalle.");

            // Validación adicional de los detalles de la factura
            foreach (var detail in invoice.InvoiceDetails)
            {
                if (detail.Quantity <= 0)
                    throw new InvalidOperationException("La cantidad del detalle de la factura debe ser mayor que cero.");
                if (detail.Price <= 0)
                    throw new InvalidOperationException("El precio del detalle de la factura debe ser mayor que cero.");
            }

            // Recalcular subtotal y total
            invoice.Subtotal = invoice.InvoiceDetails.Sum(d => d.Quantity * d.Price);
            invoice.TotalAmount = invoice.Subtotal + (invoice.Subtotal * (invoice.Tax / 100));

            await _repository.UpdateAsync(invoice);
        }

        // Eliminar una factura
        public async Task DeleteInvoiceAsync(int id)
        {
            var invoice = await _repository.GetByIdAsync(id);
            if (invoice == null)
            {
                throw new KeyNotFoundException($"Factura con ID {id} no encontrada.");
            }
            await _repository.DeleteAsync(id);
        }
    }
}
