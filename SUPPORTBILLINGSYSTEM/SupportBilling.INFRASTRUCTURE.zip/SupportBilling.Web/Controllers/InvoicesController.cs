﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using SupportBilling.Web.Models;
using System.Text;
using System.Text.Json;

namespace SupportBilling.Web.Controllers
{
    public class InvoicesController : Controller
    {
        private readonly HttpClient _httpClient;

        public InvoicesController(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri(configuration["ApiSettings:BaseUrl"]);
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var response = await _httpClient.GetAsync("Invoices");

                if (response.IsSuccessStatusCode)
                {
                    var data = await response.Content.ReadAsStringAsync();
                    var invoices = JsonSerializer.Deserialize<List<InvoiceViewModel>>(data, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    return View(invoices);
                }
                else
                {
                    ModelState.AddModelError(string.Empty, $"Error: {response.ReasonPhrase}");
                    return View(new List<InvoiceViewModel>());
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An unexpected error occurred: {ex.Message}");
                return View(new List<InvoiceViewModel>());
            }
        }

        // Crear factura
        public async Task<IActionResult> Create()
        {
            await LoadClientsAndServicesAsync(); // Cargar clientes y servicios
            var invoice = new InvoiceViewModel { InvoiceDate = DateTime.Now, Status = "Pending" }; // Establecer un estado por defecto
            await LoadStatusesAsync(); // Cargar los estados posibles
            return View(invoice);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(InvoiceViewModel invoice)
        {
            if (!ModelState.IsValid)
            {
                await LoadClientsAndServicesAsync(); // Cargar clientes y servicios si el modelo no es válido
                await LoadStatusesAsync(); // Cargar los estados si el modelo no es válido
                return View(invoice);
            }

            try
            {
                invoice.TotalAmount = invoice.Subtotal + (invoice.Subtotal * invoice.Tax / 100); // Calcular TotalAmount

                var jsonInvoice = JsonSerializer.Serialize(invoice);
                var content = new StringContent(jsonInvoice, Encoding.UTF8, "application/json");

                var response = await _httpClient.PostAsync("Invoices", content);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index)); // Redirigir a la lista de facturas
                }

                ModelState.AddModelError(string.Empty, $"Error: {response.ReasonPhrase}");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An unexpected error occurred: {ex.Message}");
            }

            await LoadClientsAndServicesAsync(); // Cargar clientes y servicios en caso de error
            await LoadStatusesAsync(); // Cargar los estados en caso de error
            return View(invoice);
        }

        // Editar factura
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            try
            {
                var response = await _httpClient.GetAsync($"Invoices/{id}");
                if (response.IsSuccessStatusCode)
                {
                    var data = await response.Content.ReadAsStringAsync();
                    var invoice = JsonSerializer.Deserialize<InvoiceViewModel>(data, new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                    await LoadClientsAndServicesAsync(); // Cargar clientes y servicios
                    await LoadStatusesAsync(); // Cargar los estados posibles
                    return View(invoice);
                }
                else
                {
                    ModelState.AddModelError(string.Empty, $"Error: {response.ReasonPhrase}");
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An unexpected error occurred: {ex.Message}");
                return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(InvoiceViewModel invoice)
        {
            if (!ModelState.IsValid)
            {
                await LoadClientsAndServicesAsync(); // Cargar clientes y servicios si el modelo no es válido
                await LoadStatusesAsync(); // Cargar los estados si el modelo no es válido
                return View(invoice);
            }

            try
            {
                invoice.TotalAmount = invoice.Subtotal + (invoice.Subtotal * invoice.Tax / 100); // Calcular TotalAmount

                var jsonInvoice = JsonSerializer.Serialize(invoice);
                var content = new StringContent(jsonInvoice, Encoding.UTF8, "application/json");

                var response = await _httpClient.PutAsync($"Invoices/{invoice.Id}", content);

                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index)); // Redirigir a la lista de facturas
                }

                ModelState.AddModelError(string.Empty, $"Error: {response.ReasonPhrase}");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An unexpected error occurred: {ex.Message}");
            }

            await LoadClientsAndServicesAsync(); // Cargar clientes y servicios en caso de error
            await LoadStatusesAsync(); // Cargar los estados en caso de error
            return View(invoice);
        }

        // Acción para eliminar una factura
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            try
            {
                var response = await _httpClient.DeleteAsync($"Invoices/{id}");
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Index)); // Redirigir a la lista de facturas
                }

                ModelState.AddModelError(string.Empty, $"Failed to delete the invoice. {response.ReasonPhrase}");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"An unexpected error occurred: {ex.Message}");
            }

            return RedirectToAction(nameof(Index));
        }

        private async Task LoadClientsAndServicesAsync()
        {
            var responseClients = await _httpClient.GetAsync("Clients");
            if (responseClients.IsSuccessStatusCode)
            {
                var jsonDataClients = await responseClients.Content.ReadAsStringAsync();
                var clients = JsonSerializer.Deserialize<List<ClientViewModel>>(jsonDataClients, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                ViewBag.Clients = new SelectList(clients, "Id", "Name");
            }
            else
            {
                ViewBag.Clients = new SelectList(new List<ClientViewModel>(), "Id", "Name");
            }

            var responseServices = await _httpClient.GetAsync("Services");
            if (responseServices.IsSuccessStatusCode)
            {
                var jsonDataServices = await responseServices.Content.ReadAsStringAsync();
                var services = JsonSerializer.Deserialize<List<ServiceViewModel>>(jsonDataServices, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                ViewBag.Services = new SelectList(services, "Id", "Name", "Price");
            }
            else
            {
                ViewBag.Services = new SelectList(new List<ServiceViewModel>(), "Id", "Name", "Price");
            }
        }

        private async Task LoadStatusesAsync()
        {
            var statuses = new List<string> { "Pending", "Paid" };
            ViewBag.Statuses = new SelectList(statuses);
        }
    }
}
