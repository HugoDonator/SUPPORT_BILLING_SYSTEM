﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace SupportBilling.Web.Models
{
    public class InvoiceViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Client is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid client.")]
        public int ClientId { get; set; }

        public string? ClientName { get; set; } // Optional for displaying the client name in the view

        [Required(ErrorMessage = "Invoice date is required.")]
        [DataType(DataType.Date)]
        public DateTime InvoiceDate { get; set; }

        [Required(ErrorMessage = "Subtotal is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Subtotal must be greater than zero.")]
        public decimal Subtotal { get; set; }

        [Required(ErrorMessage = "Tax is required.")]
        [Range(0, double.MaxValue, ErrorMessage = "Tax cannot be negative.")]
        public decimal Tax { get; set; }

        // This is the calculated field based on Subtotal and Tax
        [Display(Name = "Total Amount")]
        public decimal TotalAmount { get; set; } // Total = Subtotal + (Subtotal * Tax)

        [Required(ErrorMessage = "Service is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid service.")]
        public int ServiceId { get; set; }

        public string? ServiceName { get; set; } // Optional for displaying the service name

        [Range(0.01, double.MaxValue, ErrorMessage = "Service price must be greater than zero.")]
        public decimal ServicePrice { get; set; } // Store the price of the selected service

        // This is the status of the invoice, default is "Pending"
        [Required(ErrorMessage = "Status is required.")]
        public string Status { get; set; } = "Pending";

        // To store multiple services per invoice
        public List<InvoiceDetailViewModel> InvoiceDetails { get; set; } = new List<InvoiceDetailViewModel>();
    }

    public class InvoiceDetailViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Service ID is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Please select a valid service.")]
        public int ServiceId { get; set; }

        public string? ServiceName { get; set; } // Optional for displaying the service name

        [Required(ErrorMessage = "Quantity is required.")]
        [Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1.")]
        public int Quantity { get; set; }

        [Required(ErrorMessage = "Price is required.")]
        [Range(0.01, double.MaxValue, ErrorMessage = "Price must be greater than zero.")]
        public decimal Price { get; set; }

        // This is the calculated total for each service line (Quantity * Price)
        public decimal Total => Quantity * Price;
    }
}
