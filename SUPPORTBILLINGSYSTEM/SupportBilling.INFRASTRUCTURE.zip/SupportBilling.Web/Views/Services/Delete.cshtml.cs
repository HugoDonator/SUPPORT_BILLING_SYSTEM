using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SupportBilling.Web.Views.Services
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
